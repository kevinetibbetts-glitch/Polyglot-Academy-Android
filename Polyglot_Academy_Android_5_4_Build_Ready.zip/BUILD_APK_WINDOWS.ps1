$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "Checking local Android build tools..." -ForegroundColor Cyan
# Android Studio provides a current JDK and SDK. They are used only to BUILD the APK.
$studioJava = 'C:\Program Files\Android\Android Studio\jbr'
if (-not $env:JAVA_HOME -and (Test-Path (Join-Path $studioJava 'bin\java.exe'))) {
  $env:JAVA_HOME = $studioJava
}
if (-not $env:JAVA_HOME) {
  throw 'Java not found. Install Android Studio, then run this builder again.'
}
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$sdk = $env:ANDROID_HOME
if (-not $sdk) {$sdk = $env:ANDROID_SDK_ROOT}
if (-not $sdk) {$sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'}
if (-not (Test-Path (Join-Path $sdk 'platforms\android-35\android.jar'))) {
  throw "Android SDK Platform 35 is missing. Open Android Studio > More Actions > SDK Manager > SDK Platforms. Install Android API 35. SDK path: $sdk"
}
if (-not (Test-Path (Join-Path $sdk 'build-tools'))) {
  throw 'Android SDK Build Tools are missing. Install them in Android Studio SDK Manager.'
}
# local.properties is machine-specific and should not be copied to another computer.
("sdk.dir=" + ($sdk.Replace('\','/'))) | Set-Content -Encoding ASCII (Join-Path $root 'local.properties')
$version = '8.9'
$gradleHome = Join-Path $root "_build_tools\gradle-$version"
$gradleBat = Join-Path $gradleHome 'bin\gradle.bat'
if (-not (Test-Path $gradleBat)) {
  $tools = Join-Path $root '_build_tools'
  New-Item -ItemType Directory -Force -Path $tools | Out-Null
  $zip = Join-Path $tools "gradle-$version-bin.zip"
  Write-Host 'Downloading official Gradle 8.9 (first build only)...' -ForegroundColor Cyan
  Invoke-WebRequest -UseBasicParsing -Uri "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $zip
  Write-Host 'Unpacking Gradle...'
  Expand-Archive -Path $zip -DestinationPath $tools -Force
  Remove-Item $zip -Force
}
Write-Host 'Compiling Android APK (first build downloads Android plugin dependencies)...' -ForegroundColor Cyan
Push-Location $root
try {
  & $gradleBat --no-daemon --console=plain assembleDebug
  if ($LASTEXITCODE -ne 0) {throw "Gradle build failed (exit code $LASTEXITCODE)."}
} finally {Pop-Location}
$apk = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) {throw 'Build finished but APK was not found.'}
Copy-Item -Path $apk -Destination (Join-Path $root 'PolyglotAcademy-debug.apk') -Force
Write-Host 'SUCCESS: PolyglotAcademy-debug.apk created.' -ForegroundColor Green
