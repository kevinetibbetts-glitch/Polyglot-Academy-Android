@echo off
setlocal
cd /d "%~dp0"
echo.
echo POLYGLOT ACADEMY - ANDROID APK BUILDER
echo.
echo Requires Android Studio and Android SDK Platform 35 installed.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_APK_WINDOWS.ps1"
if errorlevel 1 (
  echo.
  echo BUILD DID NOT COMPLETE. Read the explanation above.
  pause
  exit /b 1
)
echo.
echo Build complete. Find PolyglotAcademy-debug.apk in this folder.
pause
