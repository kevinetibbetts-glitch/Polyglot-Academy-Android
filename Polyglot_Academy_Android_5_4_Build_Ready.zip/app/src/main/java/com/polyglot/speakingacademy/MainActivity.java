package com.polyglot.speakingacademy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.net.Uri;
import android.content.ClipData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Polyglot Academy for Android. Fully independent of any computer or external paid API.
 * The unreviewed lesson translations ship as an offline curriculum. Speech collection
 * only uses explicit permissive licences and all downloads are marked unverified.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_MIC = 411;
    private static final long MAX_AUDIO_BYTES = 5_000_000;
    private static final int MAX_META_BYTES = 1_500_000;
    private static final int SCAN_WORDS = 8;
    private static final int SCAN_SENTENCES = 5;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Object libraryLock = new Object();
    private JSONArray library = new JSONArray();
    private WebView web;
    private MediaRecorder recorder;
    private MediaPlayer player;
    private File voiceFile;
    private TextToSpeech tts;
    private boolean micRequested;
    private volatile boolean scanning = false;
    private File audioFolder;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        audioFolder = new File(getFilesDir(), "recordings");
        //noinspection ResultOfMethodCallIgnored
        audioFolder.mkdirs();
        voiceFile = new File(getFilesDir(), "my_voice.m4a");
        readLibrary();
        tts = new TextToSpeech(this, result -> {
            if (result != TextToSpeech.SUCCESS) onAudioMessage("Optional system voice is unavailable. Human recordings still work.");
        });
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new AppBridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Keep all remote content outside the privileged local WebView.
                if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getPathSegments().isEmpty()?"":uri.getPathSegments().get(0))) return false;
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        // Never use mobile data on startup. Downloads start only after the learner taps Find recordings.

    }

    @Override public void onDestroy() {
        try { if (recorder!=null) { recorder.stop(); recorder.release(); } } catch (Exception ignored) {}
        releasePlayer();
        if(tts!=null) { tts.stop(); tts.shutdown(); }
        io.shutdownNow();
        if(web!=null) { web.removeJavascriptInterface("Android"); web.destroy(); }
        super.onDestroy();
    }
    private void js(String call) { main.post(() -> { if(web!=null) web.evaluateJavascript(call, null); }); }
    private void onAudioMessage(String message) { js("window.onAudioMessage("+JSONObject.quote(message)+")"); }
    private void onRecordingMessage(String message) { js("window.onRecordingMessage("+JSONObject.quote(message)+")"); }
    private void runStatus(String message) { js("window.onNativeStatus("+JSONObject.quote(message)+")"); }
    private void updateLibraryUI() { js("if(window.onScanComplete)window.onScanComplete({found:0})"); }

    public class AppBridge {
        @JavascriptInterface public String getProgress(String lang) {
            if (!validLanguage(lang)) return "{}";
            return getPreferences(MODE_PRIVATE).getString("progress_"+lang,"{}");
        }
        @JavascriptInterface public void saveProgress(String lang,String json) {
            if (!validLanguage(lang)||json==null||json.length()>100000) return;
            try { new JSONObject(json); getPreferences(MODE_PRIVATE).edit().putString("progress_"+lang,json).apply(); } catch (Exception ignored) {}
        }
        @JavascriptInterface public String getClips(String lang) {
            JSONArray result=new JSONArray();
            synchronized(libraryLock) {
                for (int i=0;i<library.length();i++) {
                    JSONObject item=library.optJSONObject(i);
                    if(item!=null&&lang.equals(item.optString("lang"))) result.put(item);
                }
            }
            return result.toString();
        }
        @JavascriptInterface public void scan(String lang) {
            if(!validLanguage(lang)) return;
            if(scanning) {runStatus("A recording scan is already underway.");return;}
            scanning=true;
            io.execute(() -> {
                try {
                    int found=performScan(lang);
                    js("window.onScanComplete({found:"+found+"})");
                } catch(Exception e) {
                    js("window.onScanComplete({error:"+JSONObject.quote(brief(e))+"})");
                } finally {scanning=false;}
            });
        }
        @JavascriptInterface public void playClip(String id) { io.execute(()->playOne(id)); }
        @JavascriptInterface public void playPhrase(String lang,String text) {
            if(!validLanguage(lang)||text==null||text.length()>500) return;
            io.execute(() -> {
                JSONObject item=findMatchingClip(lang,text);
                if(item!=null) {playOne(item.optString("id"));return;}
                if("ceb".equals(lang)) {
                    onAudioMessage("No matching human Cebuano recording is saved yet. Open Real voices for authentic examples. I'm not substituting an English or Tagalog accent.");
                } else {
                    main.post(() -> speakWithSystem(lang,text));
                }
            });
        }
        @JavascriptInterface public void stopPlayback() { main.post(() -> {releasePlayer();if(tts!=null)tts.stop();}); }
        @JavascriptInterface public void clearVoice() { main.post(() -> {
            if(recorder!=null){try {recorder.stop();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}recorder=null;}
            if(voiceFile.exists())voiceFile.delete();
        }); }
        @JavascriptInterface public void shareProgress(String json) {
            if(json==null||json.length()>500000)return;
            main.post(() -> {try{
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("application/json");send.putExtra(Intent.EXTRA_TEXT,json);
                startActivity(Intent.createChooser(send,"Save Polyglot Academy progress"));
            }catch(Exception e){onAudioMessage("Could not share progress: "+brief(e));}});
        }
        @JavascriptInterface public void recordStart() { main.post(() -> startMicrophone()); }
        @JavascriptInterface public void recordStop() { main.post(() -> stopMicrophone()); }
        @JavascriptInterface public void replayVoice() { main.post(() -> {
            if(!voiceFile.exists()) {onRecordingMessage("Record yourself first.");return;}
            playLocal(voiceFile,"Playing your own voice. Compare it to the reference.");
        }); }
        @JavascriptInterface public void openSource(String id) {
            JSONObject c=findById(id);
            if(c==null) return;
            String url=c.optString("source","");
            if(!url.startsWith("https://commons.wikimedia.org/")&&!url.startsWith("https://huggingface.co/")) return;
            main.post(() -> { try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){onAudioMessage("Unable to open recording source: "+brief(e));} });
        }
    }
    private static boolean validLanguage(String x){return "ceb".equals(x)||"ko".equals(x)||"zh".equals(x)||"ja".equals(x);}
    private void readLibrary() {
        File file=new File(getFilesDir(),"speech_library.json");
        if(!file.isFile()) return;
        try(FileInputStream input=new FileInputStream(file)) {
            ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;
            while((n=input.read(buf))!=-1&&b.size()<4_000_000)b.write(buf,0,n);
            synchronized(libraryLock){library=new JSONArray(b.toString("UTF-8"));}
        }catch(Exception ignored){ synchronized(libraryLock){library=new JSONArray();} }
    }
    private void saveLibrary() {
        try {
            File tmp=new File(getFilesDir(),"speech_library.json.tmp"), dst=new File(getFilesDir(),"speech_library.json");
            try(FileOutputStream out=new FileOutputStream(tmp)){out.write(library.toString().getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
            if(!tmp.renameTo(dst)) {try(FileOutputStream out=new FileOutputStream(dst)){out.write(library.toString().getBytes(StandardCharsets.UTF_8));}}
        }catch(Exception ignored) { }
    }
    private JSONObject findById(String id) {
        if(id==null) return null;
        synchronized(libraryLock){for(int i=0;i<library.length();i++){JSONObject o=library.optJSONObject(i);if(o!=null&&id.equals(o.optString("id"))) return o;}}
        return null;
    }
    private JSONObject findMatchingClip(String lang,String phrase) {
        String normalized=normalize(phrase);
        synchronized(libraryLock){for(int i=0;i<library.length();i++){
            JSONObject o=library.optJSONObject(i);
            if(o!=null&&lang.equals(o.optString("lang"))&&normalized.equals(normalize(o.optString("text")))) return o;
        }} return null;
    }
    private static String normalize(String text){return text.trim().toLowerCase(Locale.ROOT).replaceAll("[.,?!。！？，]", "").replaceAll("\\s+"," ");}
    private static String encode(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private static String brief(Exception e){String s=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();return s.length()>160?s.substring(0,160):s;}
    private static boolean permittedUrl(String value) {
        try {
            URL url=new URL(value);
            if(!"https".equals(url.getProtocol())||url.getUserInfo()!=null) return false;
            String host=url.getHost().toLowerCase(Locale.ROOT);
            return host.equals("commons.wikimedia.org")||host.equals("upload.wikimedia.org")||host.equals("datasets-server.huggingface.co")||host.equals("huggingface.co")||host.endsWith(".huggingface.co");
        }catch(Exception e){return false;}
    }
    private static byte[] fetch(String address,int limit) throws Exception {
        String url=address;
        for(int redirects=0;redirects<=4;redirects++) {
            if(!permittedUrl(url)) throw new Exception("Source is not an approved audio host");
            HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
            c.setConnectTimeout(13000);c.setReadTimeout(18000);c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent","PolyglotAcademyAndroid/5.3 (https://commons.wikimedia.org/wiki/Commons:API; personal learning)");
            c.setRequestProperty("Accept","application/json,audio/*,*/*;q=0.5");
            try {
                int code=c.getResponseCode();
                if(code>=300&&code<400) {
                    String redirect=c.getHeaderField("Location");
                    if(redirect==null)throw new Exception("Missing audio redirect");
                    url=new URL(new URL(url),redirect).toExternalForm();continue;
                }
                if(code!=200) throw new Exception("Recording source HTTP "+code);
                int length=c.getContentLength();if(length>limit)throw new Exception("Recording exceeds download limit");
                try(InputStream in=c.getInputStream();ByteArrayOutputStream buf=new ByteArrayOutputStream()) {
                    byte[] block=new byte[8192];int n,total=0;
                    while((n=in.read(block))!=-1){total+=n;if(total>limit)throw new Exception("Recording exceeds safe size");buf.write(block,0,n);}
                    return buf.toByteArray();
                }
            }finally{c.disconnect();}
        }
        throw new Exception("Too many redirects");
    }
    private static JSONObject fetchJson(String url)throws Exception {return new JSONObject(new String(fetch(url,MAX_META_BYTES),StandardCharsets.UTF_8));}
    private static String jsonMeta(JSONObject info,String name){return info.optJSONObject(name)==null?"":info.optJSONObject(name).optString("value","");}
    private static String clean(String html){return html.replaceAll("<[^>]+>"," ").replaceAll("\\s+"," ").trim();}
    private static boolean permittedLicence(String lic) {
        String s=lic.toUpperCase(Locale.ROOT).replace('_',' ').replace('-',' ').trim();
        return s.startsWith("CC BY ")||s.startsWith("CC BY SA ")||s.startsWith("CC0")||s.startsWith("PUBLIC DOMAIN")||s.equals("PD");
    }
    private static String idFrom(String lang,String s) {
        // No external hashing libraries. Stable enough for this local corpus.
        return lang+"_"+Integer.toHexString(s.hashCode())+"_"+Integer.toHexString(s.length());
    }
    private static String[] readFileLabel(String title,String lang) {
        String c="ceb".equals(lang)?"ceb":"ko".equals(lang)?"kor":"ja".equals(lang)?"jpn":"cmn";
        Matcher m=Pattern.compile("^File:LL-.+? \\(\\Q"+c+"\\E\\)-(.+?)-(.+)\\.(wav|ogg|mp3)$",Pattern.CASE_INSENSITIVE).matcher(title);
        if(!m.matches())return null;
        return new String[]{m.group(1).trim(),m.group(2).trim(),m.group(3).toLowerCase(Locale.ROOT)};
    }
    private static String cfg(String lang){return "ceb".equals(lang)?"ceb_ph":"ko".equals(lang)?"ko_kr":"ja".equals(lang)?"ja_jp":"cmn_hans_cn";}
    private static String fileLang(String lang){return "ceb".equals(lang)?"ceb":"ko".equals(lang)?"kor":"ja".equals(lang)?"jpn":"cmn";}
    private int performScan(String lang) throws Exception {
        if(!validLanguage(lang))return 0;
        // Both collections are attempted independently, so one failure doesn't block the other.
        int added=0;String errors="";
        try{added+=scanCommons(lang);}catch(Exception e){errors="Commons: "+brief(e);}
        try{added+=scanFleurs(lang);}catch(Exception e){errors+=(errors.isEmpty()?"":"; ")+"FLEURS: "+brief(e);}
        if(added==0 && !errors.isEmpty()) throw new Exception(errors);
        // Pre-cache a small number of open-licensed recordings so listening works offline.
        // This is deliberately limited to avoid unexpected mobile data usage.
        int cached=0;
        ArrayList<JSONObject> pending = new ArrayList<>();
        synchronized(libraryLock) {
            for(int i=library.length()-1;i>=0&&pending.size()<4;i--) {
                JSONObject item=library.optJSONObject(i);
                if(item!=null&&lang.equals(item.optString("lang"))&&!item.optBoolean("downloaded"))pending.add(item);
            }
        }
        for(JSONObject item:pending) {
            try{ensureAudioSaved(item);cached++;}catch(Exception ignored){/* Metadata remains available to retry. */}
        }
        return added;
    }
    private boolean addItem(JSONObject item) {
        String id=item.optString("id");if(id.isEmpty())return false;
        synchronized(libraryLock){
            if(findById(id)!=null)return false;
            library.put(item);saveLibrary();return true;
        }
    }
    private int scanCommons(String lang) throws Exception {
        String cat="Lingua_Libre_pronunciation-"+fileLang(lang);
        String cursor=getPreferences(MODE_PRIVATE).getString("cursor_"+lang,"");
        String url="https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&generator=categorymembers&gcmtitle=Category:"+cat+"&gcmtype=file&gcmlimit=35&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata&maxlag=5";
        if(!cursor.isEmpty())url+="&gcmcontinue="+encode(cursor);
        JSONObject response=fetchJson(url);if(response.has("error"))throw new Exception(response.getJSONObject("error").optString("info","Wikimedia unavailable"));
        JSONObject query=response.optJSONObject("query");JSONArray pages=query==null?new JSONArray():query.optJSONArray("pages");if(pages==null)pages=new JSONArray();
        int added=0;
        for(int i=0;i<pages.length()&&added<SCAN_WORDS;i++){
            JSONObject p=pages.optJSONObject(i);if(p==null)continue;
            String title=p.optString("title");
            String[] label=readFileLabel(title,lang);
            if(label==null||label[1].isEmpty())continue;
            JSONArray infos=p.optJSONArray("imageinfo");if(infos==null||infos.length()==0)continue;
            JSONObject info=infos.optJSONObject(0);if(info==null)continue;
            String urlAudio=info.optString("url","");if(!permittedUrl(urlAudio))continue;
            if(info.optLong("size",0L)>MAX_AUDIO_BYTES)continue;
            JSONObject meta=info.optJSONObject("extmetadata");if(meta==null)continue;
            String lic=clean(jsonMeta(meta,"LicenseShortName"));if(!permittedLicence(lic))continue;
            String author=clean(jsonMeta(meta,"Artist"));if(author.isEmpty())author=label[0];
            JSONObject item=new JSONObject();String id=idFrom(lang,title);
            item.put("id",id);item.put("lang",lang);item.put("text",label[1]);item.put("speaker",label[0]);item.put("credit",author);
            item.put("license",lic);item.put("licenseUrl",clean(jsonMeta(meta,"LicenseUrl")));
            item.put("source","https://commons.wikimedia.org/wiki/"+encode(title.replace(' ','_')));
            item.put("mediaUrl",urlAudio);item.put("extension",label[2]);item.put("sourceType","commons");item.put("downloaded",false);
            item.put("status","unreviewed");
            if(addItem(item)) added++;
        }
        JSONObject continuation=response.optJSONObject("continue");
        String next=continuation==null?"":continuation.optString("gcmcontinue","");
        getPreferences(MODE_PRIVATE).edit().putString("cursor_"+lang,next).apply();
        return added;
    }
    private int scanFleurs(String lang) throws Exception {
        int offset=getPreferences(MODE_PRIVATE).getInt("fleurs_offset_"+lang,0);
        String url="https://datasets-server.huggingface.co/rows?dataset=google%2Ffleurs&config="+cfg(lang)+"&split=validation&offset="+offset+"&length="+SCAN_SENTENCES;
        JSONObject data=fetchJson(url);JSONArray rows=data.optJSONArray("rows");if(rows==null)throw new Exception("No FLEURS rows returned");
        int added=0;
        for(int i=0;i<rows.length();i++) {
            JSONObject rowWrapper=rows.optJSONObject(i);if(rowWrapper==null)continue;
            int rowId=rowWrapper.optInt("row_idx",-1);if(rowId<0)continue;
            JSONObject row=rowWrapper.optJSONObject("row");if(row==null)continue;
            String text=row.optString("raw_transcription",row.optString("transcription","")).trim();
            JSONObject audio=row.optJSONObject("audio");String media=audio==null?"":audio.optString("src","");
            if(text.isEmpty()||text.length()>350||!permittedUrl(media))continue;
            JSONObject item=new JSONObject();item.put("id",idFrom(lang,"fleurs_"+rowId));item.put("lang",lang);item.put("text",text);
            item.put("speaker","FLEURS speaker (identity not provided)");item.put("credit","Google FLEURS and contributing speakers");
            item.put("license","CC BY 4.0");item.put("licenseUrl","https://creativecommons.org/licenses/by/4.0/");
            item.put("source","https://huggingface.co/datasets/google/fleurs/viewer/"+cfg(lang)+"/validation?row="+rowId);
            item.put("mediaUrl",media);item.put("sourceType","fleurs");item.put("extension","wav");item.put("rowIndex",rowId);
            item.put("status","unreviewed");item.put("downloaded",false);
            if(addItem(item)) added++;
        }
        int count=data.optInt("num_rows_total",0),next=offset+rows.length();
        getPreferences(MODE_PRIVATE).edit().putInt("fleurs_offset_"+lang, count>0&&next>=count?0:next).apply();
        return added;
    }
    private File audioFile(JSONObject item) {
        String extension=item.optString("extension","wav");
        if(!extension.matches("wav|ogg|mp3"))extension="wav";
        return new File(audioFolder,item.optString("id").replaceAll("[^a-zA-Z0-9_]", "_")+"."+extension);
    }
    private static boolean validAudio(byte[] data) {
        return data.length>16&&((data[0]=='R'&&data[1]=='I'&&data[2]=='F'&&data[3]=='F'&&data[8]=='W') ||
            (data[0]=='O'&&data[1]=='g'&&data[2]=='g'&&data[3]=='S') ||
            (data[0]=='I'&&data[1]=='D'&&data[2]=='3') ||
            ((data[0]&0xff)==0xff&&(data[1]&0xe0)==0xe0));
    }
    private String refreshFleursUrl(JSONObject clip)throws Exception {
        int idx=clip.optInt("rowIndex",-1);if(idx<0)throw new Exception("Missing FLEURS row");
        String url="https://datasets-server.huggingface.co/rows?dataset=google%2Ffleurs&config="+cfg(clip.optString("lang"))+"&split=validation&offset="+idx+"&length=1";
        JSONArray rows=fetchJson(url).optJSONArray("rows");if(rows==null||rows.length()!=1)throw new Exception("Sentence audio unavailable");
        JSONObject row=rows.getJSONObject(0).optJSONObject("row");JSONObject audio=row==null?null:row.optJSONObject("audio");
        String src=audio==null?"":audio.optString("src","");
        if(!permittedUrl(src))throw new Exception("Unexpected audio address");
        clip.put("mediaUrl",src);return src;
    }
    private File ensureAudioSaved(JSONObject clip) throws Exception {
        File audio=audioFile(clip);
        if(audio.isFile() && audio.length()>16) return audio;
        String url=clip.optString("sourceType").equals("fleurs")?refreshFleursUrl(clip):clip.optString("mediaUrl");
        byte[] data=fetch(url,(int)MAX_AUDIO_BYTES);
        if(!validAudio(data)) throw new Exception("The file was not a recognizable audio format");
        File temp=new File(audio.getAbsolutePath()+".tmp");
        try(FileOutputStream out=new FileOutputStream(temp)){out.write(data);}
        if(!temp.renameTo(audio)) throw new Exception("Could not save audio locally");
        synchronized(libraryLock){clip.put("downloaded",true);saveLibrary();}
        return audio;
    }
    private void playOne(String id) {
        JSONObject clip=findById(id);
        if(clip==null){onAudioMessage("Recording not found.");return;}
        try {
            if(!audioFile(clip).isFile()) onAudioMessage("Downloading human recording…");
            File audio=ensureAudioSaved(clip);
            main.post(() -> playLocal(audio,"Human recording saved for offline replay. Pronunciation is not independently verified."));
        } catch(Exception e){onAudioMessage("Recording unavailable: "+brief(e));}
    }
    private void releasePlayer(){if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}}
    private void playLocal(File audio,String message){
        releasePlayer();
        try {
            player=new MediaPlayer();player.setDataSource(audio.getAbsolutePath());player.setOnCompletionListener(p->releasePlayer());player.prepare();player.start();onAudioMessage(message);
        }catch(Exception e){releasePlayer();onAudioMessage("Cannot play this audio format on your device: "+brief(e));}
    }
    private void speakWithSystem(String lang,String text) {
        if(tts==null){onAudioMessage("No suitable voice installed. Try Real voices.");return;}
        Locale locale="ko".equals(lang)?Locale.KOREAN:"ja".equals(lang)?Locale.JAPANESE:Locale.SIMPLIFIED_CHINESE;
        if(tts.isLanguageAvailable(locale)<TextToSpeech.LANG_AVAILABLE){onAudioMessage("No "+("ko".equals(lang)?"Korean":"ja".equals(lang)?"Japanese":"Mandarin")+" Android speech voice installed. Use Real voices instead.");return;}
        tts.setLanguage(locale);tts.setSpeechRate(0.92f);
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"polyglot_phrase");
        onAudioMessage("Android synthetic voice — convenient practice, but not a native-verified pronunciation reference.");
    }
    private void startMicrophone() {
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            micRequested=true;requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQUEST_MIC);return;
        }
        if(recorder!=null)return;
        try {
            releasePlayer();
            if(voiceFile.exists()) voiceFile.delete();
            recorder=Build.VERSION.SDK_INT>=31?new MediaRecorder(this):new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setOutputFile(voiceFile.getAbsolutePath());
            recorder.prepare();recorder.start();
            js("window.onRecordingChanged(true)");
            onRecordingMessage("Recording… Say the phrase and tap Stop.");
        }catch(Exception e){if(recorder!=null){recorder.release();recorder=null;}js("window.onRecordingChanged(false)");onRecordingMessage("Microphone error: "+brief(e));}
    }
    private void stopMicrophone() {
        if(recorder==null){js("window.onRecordingChanged(false)");return;}
        boolean ok=false;
        try{recorder.stop();ok=true;}catch(Exception ignored){voiceFile.delete();}
        try{recorder.release();}catch(Exception ignored){}
        recorder=null;js("window.onRecordingChanged(false)");
        js("window.onRecordingSaved("+ok+")");
        onRecordingMessage(ok?"Recorded! Tap Hear myself to compare with the original.":"That recording was too short. Try again.");
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==REQUEST_MIC&&micRequested){micRequested=false;
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startMicrophone();
            else onRecordingMessage("Microphone permission is needed for Speak. You can enable it in Android app settings.");
        }
    }
}
