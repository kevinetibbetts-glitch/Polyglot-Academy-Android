POLYGLOT ACADEMY — ANDROID 5.4
================================
This is Android source, NOT an installable APK. Do not transfer this ZIP to your phone and expect it to install.

FEATURES BUILT INTO THE ANDROID PROJECT
Four offline courses: Cebuano, Korean, Mandarin and Japanese.
Guided colorful lessons, reviews, quizzes, writing, app-local saved progress.
Android microphone recording, Clear, Hear myself; Android TTS if a language voice exists.
Real Voices collection from permitted human speech sources with attribution and review labels.
A computer is not needed once the APK has been built and installed.

ONE-TIME APK BUILD (NO ANDROID STUDIO REQUIRED IF USING GITHUB ACTIONS)
1. Create a private GitHub repository; upload this project folder's CONTENTS to the repository root.
2. Open the repository Actions tab > Build Polyglot Android APK > Run workflow.
3. When complete, download the artifact PolyglotAcademy-Android-5.4-APK.
4. Unzip the artifact, transfer app-debug.apk to your phone, and open it to install.
   Android may ask for permission to install from the selected Files/browser app.

ALTERNATIVE BUILD ON YOUR WINDOWS PC
Open the extracted project root and run BUILD_APK_WINDOWS.bat.
Requires Android Studio or equivalent Android SDK and internet on the first build.

KNOWN LIMITATIONS
This build has NOT been compiled or installed on a physical Android device in the development environment.
The development environment has no Android SDK, APK compiler or device; a cloud build is provided instead.
The full 307-phrase curriculum is offline, but 307 recordings are NOT bundled.
Cebuano does not have a reliable synthetic fallback; some Listen buttons require a matching saved human clip.
Human recordings are marked unverified until assessed by a fluent speaker.
Audio collection requires internet and provider APIs remaining operational.
There is no valid automated native accent grading.

Privacy: the application stores learner progress and microphone recordings on the device.
No paid AI keys are required for its existing lessons. Recording search requires internet.
